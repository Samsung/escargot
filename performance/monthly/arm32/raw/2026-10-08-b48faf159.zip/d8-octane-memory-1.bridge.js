globalThis.benchmarkCheckpoint = function(label) {
print('MEM_CHECKPOINT ' + JSON.stringify(label));
var ack = readline();
if (typeof ack !== 'string' || ack.trim() !== 'continue') throw Error('Memory barrier failed');
};
